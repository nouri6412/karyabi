<div class="share-details-btn">
    <ul>
        <li>
            <h5 class="m-a0">اشتراک گذاری پست</h5>
        </li>
        <li><a href="javascript:void(0);" class="social-share site-button facebook button-sm"><i class="fa fa-facebook"></i> فیسبوک</a></li>
        <li><a href="javascript:void(0);" class="social-share site-button google-plus button-sm"><i class="fa fa-google-plus"></i> گوگل پلاس</a></li>
        <li><a href="javascript:void(0);" class="social-share site-button linkedin button-sm"><i class="fa fa-linkedin"></i> لینکیدین</a></li>
        <li><a href="javascript:void(0);" class="social-share site-button instagram button-sm"><i class="fa fa-instagram"></i> اینستاگرام</a></li>
        <li><a href="javascript:void(0);" class="social-share site-button twitter button-sm"><i class="fa fa-twitter"></i> توییتر</a></li>
        <!-- <li><a href="javascript:void(0);" class="social-share site-button whatsapp button-sm"><i class="fa fa-whatsapp"></i> واتس آپ</a></li> -->
    </ul>
</div>