<?php
$data = get_field("footer-copy", 'option');
?>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <span> © کپی رایت 1400 با <i class="fa fa-heart m-lr5 text-red heart"></i>
                        <a href="#"><?php  echo 'Karyabi'; ?> </a> همه حقوق محفوظ است.</span>
                </div>
            </div>
        </div>
    </div>