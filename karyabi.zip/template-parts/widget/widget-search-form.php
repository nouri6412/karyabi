<div class="widget">
    <h6 class="widget-title">جستجو</h6>
    <div class="search-bx style-1">
        <?php get_search_form(); ?>
    </div>
</div>