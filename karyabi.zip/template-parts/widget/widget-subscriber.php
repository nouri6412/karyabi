<div class="widget widget-newslatter">
    <h6 class="widget-title">خبرنامه</h6>
    <div class="news-box">
        <p>برای دریافت خبرنامه ایمیل خود را وارد کنید</p>
        <form class="dzSubscribe" action="script/mailchamp.php" method="post">
            <div class="dzSubscribeMsg"></div>
            <div class="input-group">
                <input name="dzEmail" required="required" type="email" class="form-control" placeholder="ایمیل">
                <button name="submit" value="submit" type="submit" class="site-button btn-block">عضویت</button>
            </div>
        </form>
    </div>
</div>