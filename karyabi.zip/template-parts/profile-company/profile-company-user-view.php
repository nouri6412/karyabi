<div class="modal fade lead-form-modal user-detail" id="user-details" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body row m-a0 clearfix">
                <div class="col-lg-12 col-md-12 p-a0">
                        <div id="content-user-resume"></div>
                        <div class="box-loading">
                            <div class="loading-ajax"></div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Modal Box End -->