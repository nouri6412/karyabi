// define( 'DB_NAME', 'blitdani_karyabi' );

// /** MySQL database username */
// define( 'DB_USER', 'blitdani_crm' );

// /** MySQL database password */
// define( 'DB_PASSWORD', 'fl(QdXZ~JDVH' );

// /** MySQL hostname */
// define( 'DB_HOST', '185.159.153.76' );